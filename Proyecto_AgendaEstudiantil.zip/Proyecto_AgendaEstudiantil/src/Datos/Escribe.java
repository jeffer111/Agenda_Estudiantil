/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Gui.Principal;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author jeffer
 */
public class Escribe {
    String nombredefichero;
    File fichero;
    Principal p=new Principal();
    


    public Escribe( File fichero) {
        this.fichero = fichero;
    }

    public File getFichero() {
        return fichero;
    }

    public void setFichero(File fichero) {
        this.fichero = fichero;
    }

    public void Escribir(String texto){
/*        if(getFichero().exists()){
            JOptionPane.showMessageDialog(p,"Ya Existe Fichero");
        }
        else {*/
	      try{
                      BufferedWriter bw = new BufferedWriter(new FileWriter(fichero));
                      bw.write(texto);

	               bw.close();
              }catch(IOException ioe){
                  JOptionPane.showMessageDialog(p,"Error Al Escribir En el Fichero");
              }
        //}
    }
}
