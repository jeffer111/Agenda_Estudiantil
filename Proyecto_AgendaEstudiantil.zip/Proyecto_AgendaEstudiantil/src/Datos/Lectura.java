/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Gui.Principal;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author jeffer
 */
public class Lectura {
    String nombredefichero;
    File fichero;
    Principal p=new Principal();
    
    public Lectura(File file) {
        this.fichero =file;
    }

    public File getFichero() {
        return fichero;
    }

    public void setFichero(File fichero) {
        this.fichero = fichero;
    }

    public String Leer(){
        String sCadena="",aux="";
        try {
	     FileReader fr = new FileReader(fichero);
	     BufferedReader bf = new BufferedReader(fr);

	      while ((aux = bf.readLine())!=null) {
			sCadena=sCadena+aux+"\n";
		}
	 } catch (FileNotFoundException fnfe){
             sCadena="Error No Se Encuentra El Archivo Especificado";
	} catch (IOException ioe){
            sCadena="Error Al Leer En el Fichero";
	}
        return sCadena;
    }
}
