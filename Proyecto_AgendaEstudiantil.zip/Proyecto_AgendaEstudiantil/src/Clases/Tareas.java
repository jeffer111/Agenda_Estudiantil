/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author jeffer
 */
public class Tareas {
    public String materia;
    public String titulo;
    public String descripcion;
    public Tareas siguiente;

    public void Tareas(String materia, String titulo, String descripcion, Tareas siguiente) {
        this.materia = materia;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.siguiente = siguiente;
    }

    public Tareas getSiguiente() {
        return siguiente;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public String getMateria() {
        return materia;
    }

    public void setSiguiente(Tareas siguiente) {
        this.siguiente = siguiente;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
}
