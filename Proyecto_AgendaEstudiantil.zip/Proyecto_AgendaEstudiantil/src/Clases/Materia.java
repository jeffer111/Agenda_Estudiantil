/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author jeffer
 */
public class Materia {
    public String nombre;
    public static String Ref; 
    public Materia siguiente;

    public void Materia(String nombre, Materia siguiente) {
        this.nombre = nombre;
        this.siguiente = null;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public static void setRef(String Ref) {
        Materia.Ref = Ref;
    }

    public static String getRef() {
        return Ref;
    }

    

    public Materia getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(Materia siguiente) {
        this.siguiente = siguiente;
    }


}
