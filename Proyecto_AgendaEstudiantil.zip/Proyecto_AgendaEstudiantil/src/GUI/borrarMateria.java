/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import javax.swing.table.DefaultTableModel;

/**
 *
 * @author jeffer
 */
public class borrarMateria extends javax.swing.JFrame {
    int cont=0;
    private DefaultTableModel mostrarMate;
    
    public borrarMateria() {
        initComponents();
        this.setTitle("BORRAR UNA MATERIA");
        this.setLocationRelativeTo(null);
        cargarInterfazDos();
    }

    public void cargarInterfazDos(){
        String x[][]={};
        String columnas[]={"           MATERIAS REGISTRADAS"};
        mostrarMate = new DefaultTableModel(x, columnas);
        mostrarMateri.setModel(mostrarMate);
        
    }
    public void mostrarDatosDos(String mat){
        mostrarMate.insertRow(cont, new Object[]{});  //Insertar un Objeto en un fila determinada
        mostrarMate.setValueAt(mat,cont,0); //Darle el valor del Objeto a esa fila
        cont++;
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        mostrarMateri = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        matBorrar = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(400, 350));
        getContentPane().setLayout(null);

        mostrarMateri.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "MATERIAS REGISTRADAS"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(mostrarMateri);
        if (mostrarMateri.getColumnModel().getColumnCount() > 0) {
            mostrarMateri.getColumnModel().getColumn(0).setResizable(false);
        }

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(80, 110, 240, 130);

        jButton1.setText("Aceptar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(80, 255, 90, 23);

        jButton2.setText("Salir");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2);
        jButton2.setBounds(241, 255, 90, 23);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(0, 98, 400, 10);

        jLabel1.setFont(new java.awt.Font("Showcard Gothic", 1, 11)); // NOI18N
        jLabel1.setText("Materia a Borrar:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(40, 55, 130, 20);

        matBorrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                matBorrarActionPerformed(evt);
            }
        });
        getContentPane().add(matBorrar);
        matBorrar.setBounds(170, 50, 142, 26);

        jLabel2.setFont(new java.awt.Font("Showcard Gothic", 1, 14)); // NOI18N
        jLabel2.setText("BORRAR MATERIA");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(127, 11, 136, 18);

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/borrado_mat.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(-30, -40, 470, 410);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void matBorrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_matBorrarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_matBorrarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        if(Interfaz.borrar_materia()==false){
            this.setVisible(false);
        }
        else{
            this.setVisible(true);
        }
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    public static javax.swing.JTextField matBorrar;
    private javax.swing.JTable mostrarMateri;
    // End of variables declaration//GEN-END:variables
}
