/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import java.io.File;
import javax.swing.JFileChooser;


/**
 *
 * @author jeffer
 */
public class Seleccion {
    Principal p;
    JFileChooser selector=new JFileChooser(System.getProperty("user.dir"));
    MisFiltros filtrotxt;
    MisFiltros filtrolist;



    public Seleccion() {
        filtrolist=new MisFiltros("list","Archivos De Lista");
        filtrotxt=new MisFiltros("txt","Archivos De Texto");
        selector.addChoosableFileFilter(filtrotxt);
        selector.addChoosableFileFilter(filtrolist);
        selector.setAcceptAllFileFilterUsed(false);

   
    }
    
    public File Abrir(){
        selector.setDialogTitle("Abrir Lista De Actividades");
        File f;
        int returnVal = selector.showOpenDialog(p);

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = selector.getSelectedFile();
                    f=file;

                } else {
                   
                    return null;
                }

        return f;
    }
    public File guardar(){
        selector.setDialogTitle("Guardas Avances");
        File g;
        int returnVal = selector.showSaveDialog(p);

                if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = selector.getSelectedFile();
                    g=file;
                } else {
                   return null;
                }
        return g;
    }

}
