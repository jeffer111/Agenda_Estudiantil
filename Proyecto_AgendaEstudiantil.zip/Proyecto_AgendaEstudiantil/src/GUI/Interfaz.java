/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gui;

import Datos.Lectura;
import Datos.Escribe;
import Negocios.Lista;
import Clases.Materia;
import Clases.Tareas;
import java.io.File;
import javax.swing.JOptionPane;

/**
 *
 * @author jeffer
 */
public class Interfaz {

    public static Lista lista = new Lista();

    public static boolean ingreso_materia(){
        if(ingresoMaterias.nuevaMateria.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        else{
            Materia mat= new Materia();
            mat.setNombre(ingresoMaterias.nuevaMateria.getText());
            mat.setRef("Ok");
            if(lista.empilar_mat(mat.getNombre())==true)
            {
                JOptionPane.showMessageDialog(null, "MATERIA REGISTRADA !", null, JOptionPane.PLAIN_MESSAGE); 
                return true; 
            }
            else{
                return false;
            }
                
        }     
    }
    
    public static boolean ingreso_tarea(){
        if(ingresoTareas.tituTar.getText().isEmpty()&&ingresoTareas.nombreMat.getText().isEmpty()&&ingresoTareas.descTar.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if(ingresoTareas.nombreMat.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if(ingresoTareas.descTar.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        else{
            Tareas tar= new Tareas();
            tar.setDescripcion(ingresoTareas.descTar.getText());
            tar.setMateria(ingresoTareas.nombreMat.getText());
            tar.setTitulo(ingresoTareas.tituTar.getText());
            if(lista.agregar_tarea(tar.getMateria(),tar.getTitulo(),tar.getDescripcion())==true){
                JOptionPane.showMessageDialog(null, "TAREA REGISTRADA !", null, JOptionPane.PLAIN_MESSAGE);  
            }
            else{
                JOptionPane.showMessageDialog(null, "NO SE REGISTRO LA TAREA, MATERIA NO REGISTRADA!", "Error", JOptionPane.ERROR_MESSAGE); 
            }
                  
            return true;     
        } 
    }

     public static void cargarDatosMat() throws Exception{
        listarMaterias listar=new listarMaterias();
        listar.setVisible(true);
        for(int i=0;i<lista.getTamanio_mat();i++){
            listar.mostrarDatos(lista.getValor(i));
        }
     }   
     
     public static void cargarDatosMatDos() throws Exception{
        borrarMateria listado=new borrarMateria();
        listado.setVisible(true);
        for(int i=0;i<lista.getTamanio_mat();i++){
            listado.mostrarDatosDos(lista.getValor(i));
        }
     }
     
     public static void cargarDatosTar() throws Exception{
         if(listarTareas.buscarMateria.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
        }
         else{      
            String materia_tarea= listarTareas.buscarMateria.getText();                  
            listarTareas listado=new listarTareas();
            listado.setVisible(true);
            if(lista.listar_tar(materia_tarea)==true){
                String titulo;
                String descripcion;
                for(int i=0;i<lista.getTamanio_tar();i++){
                    if(!"invalido".equals(lista.getValor_tareasDescrip(i,materia_tarea))){
                        System.out.println("ACA");
                        descripcion= lista.getValor_tareasDescrip(i,materia_tarea);
                        titulo=lista.getValor_tareasTitulo(i,materia_tarea);
                        listado.mostrarDatos(titulo, descripcion);
                    }
                }
            }
            else{
                JOptionPane.showMessageDialog(null, "MATERIA NO REGISTRADA", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
     }
     
     public static boolean cargarDatosTarDos() throws Exception{
         if(editarTarea.listarMat.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
         else{     
            String materia_tarea= editarTarea.listarMat.getText();                  
            if(lista.listar_tar(materia_tarea)==true){
                editarTarea listado2=new editarTarea(1);
                listado2.setVisible(true);
                String titulo;
                String descripcion;
                for(int i=0;i<lista.getTamanio_tar();i++){
                    if(!"invalido".equals(lista.getValor_tareasDescrip(i,materia_tarea))){
                        System.out.println("ACA");
                        descripcion= lista.getValor_tareasDescrip(i,materia_tarea);
                        titulo=lista.getValor_tareasTitulo(i,materia_tarea);
                        listado2.mostrarDatosEdi(titulo, descripcion);
                    }
                }
                return true;
            }
            else{
                editarTarea listado3=new editarTarea(0);
                listado3.setVisible(true);
                JOptionPane.showMessageDialog(null, "MATERIA NO REGISTRADA", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }     
        }
     }
    public static boolean editar_descripcion_tarea(String materia){
        if(editarTarea.ediDescrip.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if(editarTarea.descripNew.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        else{
             String descripcionaux= editarTarea.ediDescrip.getText();
             String nuevadescripcion= editarTarea.descripNew.getText();
             lista.editar_Tarea_Descripcion(materia, nuevadescripcion, descripcionaux);
             return true;        
        }
    }

    public static boolean editar_titulo_tarea(String materia){
        if(editarTarea.ediTitulo.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if(editarTarea.tituloNew.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        else{
             String tituloaux= editarTarea.ediTitulo.getText();
             String nuevotitulo= editarTarea.tituloNew.getText();
             lista.editar_Tarea_Titulo(materia, tituloaux, nuevotitulo);
             return true;        
        }
    }
    
     public static boolean editar_materia(){
         if(editarMateria.matEditar.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return true;
        }
         if(editarMateria.nombreNuevo.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return true;
         }
         else{
            String materia_editar= editarMateria.matEditar.getText();
            if(lista.buscar(materia_editar)==true){     
                String materia_nueva= editarMateria.nombreNuevo.getText();                  
                lista.editar_Materia(materia_editar, materia_nueva); 
                JOptionPane.showMessageDialog(null, "EDICION EXITOSA", null, JOptionPane.PLAIN_MESSAGE); 
                return false;
            }
            else{
                JOptionPane.showMessageDialog(null, "MATERIA NO REGISTRADA", "Error", JOptionPane.ERROR_MESSAGE);
                return true;
            }     
        }
     }
     
     public static boolean borrar_materia(){
        if(borrarMateria.matBorrar.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return true;
        }
        else{
            String borrar_materia= borrarMateria.matBorrar.getText();
            if(lista.borrar_materia(borrar_materia)==false){
                return false;
            }
            else{
                return true;
            }
            
        }
     }
     public static boolean terminarTarea(){
         if(finalizarTarea.matEliminar.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
         if(finalizarTarea.tituEliminar.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "DEBE LLENAR TODOS LOS CAMPOS", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
         else{
             String matref= finalizarTarea.matEliminar.getText();
             String tareatitulo= finalizarTarea.tituEliminar.getText();
             lista.borrar_tarea(matref, tareatitulo);
             return true;
         }
                
     }
     public static void cargarDatos(){
        Seleccion o = new Seleccion();
        File file = o.Abrir();
        if (file != null) {
            Lectura leer = new Lectura(file);
            String cad = leer.Leer();
            lista.dividir_texto(cad);
            if (!lista.esVacia()) {
                JOptionPane.showMessageDialog(null, "Datos cargados");
            } else {
                JOptionPane.showMessageDialog(null, "Error De Lectura");
            }
        }
     }
    public static void guardarDatos(){
        Seleccion g = new Seleccion();
        File file = g.guardar();
        String texto = lista.Texto();
        if (file != null) {
           Escribe escribir = new Escribe(file);
           escribir.Escribir(texto);
        }
    }
    
}

