/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Negocios;

import Clases.Materia;
import Clases.Tareas;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;

/**
 *
 * @author jeffer
 */
public class Lista {
    private Materia inicio;
    private Tareas principio;
    private int tamanio_mat,tamanio_tar;
    
    public void Lista(){
        inicio= null;
        principio= null;
        tamanio_mat = 0;
        tamanio_tar = 0;
    }
    public boolean esVacia(){
        return inicio == null;
    }

    public int getTamanio_mat(){
        return tamanio_mat;
    }
    public int getTamanio_tar(){
        return tamanio_tar;
    }

    public boolean empilar_mat(String nombre){
        if(buscar(nombre)==false){
            Materia nuevo = new Materia();
            nuevo.setNombre(nombre);
            if (esVacia()) {
                inicio = nuevo;
            } else{
                nuevo.setSiguiente(inicio);
                inicio = nuevo;
            }
            tamanio_mat++;
            return true;
        }
        else{
            JOptionPane.showMessageDialog(null, "MATERIA YA AGREGADA, VUELVA A INTENTARLO", "Error", JOptionPane.ERROR_MESSAGE); 
            return false;
        }    
    }
    
    
    public void empilar_tarea(String titulo,String descripcion,String materia){
        Tareas nuevo = new Tareas();
        // Agrega al valor al nodo.
        nuevo.setDescripcion(descripcion);
        nuevo.setTitulo(titulo);
        nuevo.setMateria(materia);
        if (esVacia()) {
            principio = nuevo;
        } else{
            nuevo.setSiguiente(principio);
            principio = nuevo;
        }
        tamanio_tar++;
    }
    
    public boolean buscar(String nombre){
        Materia aux = inicio;
        boolean encontrado = false;
        while(aux != null && encontrado != true){
            if (nombre.equals(aux.getNombre())){
                encontrado = true;
            }
            else{
                
                aux = aux.getSiguiente();
            }
        }
        return encontrado;
    }
    public boolean buscar_tarea_descripcion(String materia,String descripcion){
        Tareas aux = principio;
        boolean encontrado = false;
        while(aux != null && encontrado != true){
            if (materia.equals(aux.getMateria()) && descripcion.equals(aux.getDescripcion())){
                encontrado = true;
                
            }
            else{
                aux = aux.getSiguiente();
            }
        }
        if (encontrado==false){
            System.out.println("");
        }
        return encontrado;
    }
    
    public boolean buscar_tarea(String materia,String titulo){
        Tareas aux = principio;
        boolean encontrado = false;
        while(aux != null && encontrado != true){
            if (materia.equals(aux.getMateria()) && titulo.equals(aux.getTitulo())){
                encontrado = true;
                
            }
            else{
                aux = aux.getSiguiente();
            }
        }
        if (encontrado==false){
            System.out.println("");
        }
        return encontrado;
    }
    
    public void listar_mat(){
        if (!esVacia()) {
            Materia aux = inicio;
            int i = 0;
            while(aux != null){
                //System.out.print(i + ".[ " + aux.getNombre()+ " ]" + "\n");
                aux = aux.getSiguiente();
                i++;
            }
        }
    }
    ///
    public boolean listar_tar(String materia){
        if (buscar(materia)==true) {
            Materia aux = inicio;
            boolean estado = false;
            int i = 1;
            int refe = 0;
            //System.out.print("Lista de tareas de la materia: "+materia+"\n");
            while(aux != null && estado != true){
                if (materia.equals(aux.getNombre())){
                    refe++;
                    Tareas auxiliar=principio;
                    while(auxiliar != null){
                        if(materia.equals(auxiliar.getMateria())){
                           // System.out.print("Tarea "+i+"\nTitulo:" + auxiliar.getTitulo()+"\nDescripcion:"+ auxiliar.getDescripcion()+ "\n");
                            estado = true;
                            i++;
                        }        
                        auxiliar = auxiliar.getSiguiente();      
                    }  
                    estado = true;
                }
                else{
                    aux = aux.getSiguiente();
                }
            }
            if(refe!=0){
                if(i==1){
                    JOptionPane.showMessageDialog(null, "MATERIA SIN TAREAS", null, JOptionPane.PLAIN_MESSAGE); 
                    return true;
                }
                else{
                    return true;
                }      
            }   
            else{
                return false;
            }
        }
        else{
            return false;   
        }
        
    }
    public boolean agregar_tarea(String materia, String titulo, String descripcion){
        Materia aux = inicio;
        boolean estado = false;
        while(aux != null && estado != true){
            if (materia.equals(aux.getNombre())){
                empilar_tarea(titulo, descripcion, materia);
                estado = true;
            }
            else{
                aux = aux.getSiguiente();
            }
        }
        return estado;
    }
    public boolean borrar_materia(String materia){
        if (buscar(materia)) {
            if (materia.equals(inicio.getNombre())) {
                inicio = inicio.getSiguiente();
            } else{
                Materia aux = inicio;
                while(!aux.getSiguiente().getNombre().equals(materia)){
                    aux = aux.getSiguiente();
                }
                Materia siguiente = aux.getSiguiente().getSiguiente();
                aux.setSiguiente(siguiente);  
                
            }
            JOptionPane.showMessageDialog(null, "Materia Borrada Existosamente", null, JOptionPane.PLAIN_MESSAGE);  
            tamanio_mat--;
            return false;
        }
        else{
            JOptionPane.showMessageDialog(null, "Materia no Registrada", "Error", JOptionPane.OK_OPTION);
            return true;
        }
    }
    public void editar_Materia(String materia_editar,String nueva_materia){
        if (buscar(materia_editar)) {
            Materia aux = inicio;
            while(!aux.getNombre().equals(materia_editar)){
                aux = aux.getSiguiente();
            }
            aux.setNombre(nueva_materia);
            editar_materiaEnTar(materia_editar,nueva_materia);
           // System.out.println("EDICION EXISTOSA MATERIA:"+materia_editar+" NUEVO NOMBRE: "+nueva_materia);
        }
        else{
            System.out.println("");
        }
    }
    public void editar_materiaEnTar(String Materia,String Nueva_materia){
        Tareas aux= principio;
        while(aux!=null){
            
            if(aux.getMateria().equals(Materia)){
                aux.setMateria(Nueva_materia);
            }
            else{
                aux= aux.getSiguiente();
            }
        }
    }
    public void editar_Tarea_Descripcion(String materia,String nueva_descripcion,String descripcion){
        if (buscar_tarea_descripcion(materia,descripcion)) {
            Tareas aux = principio;
            boolean editado=false; 
            while(aux != null && editado != true){
                if(aux.getDescripcion().equals(descripcion) && aux.getMateria().equals(materia)){
                    editado=true;
                    aux.setDescripcion(nueva_descripcion);
                    JOptionPane.showMessageDialog(null, "EDICION EXITOSA", null, JOptionPane.PLAIN_MESSAGE); 
                
                }
                else{
                    aux = aux.getSiguiente();
                }
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "DESCRIPCION NO REGISTRADA, NO SE PUEDE EDITAR", "Error", JOptionPane.PLAIN_MESSAGE); 
        }
    }
    
    public void editar_Tarea_Titulo(String materia,String titulo,String nuevo_titulo){
        if (buscar_tarea(materia,titulo)) {
            Tareas aux = principio;
            boolean editado=false; 
            while(aux != null && editado != true){
                if(aux.getTitulo().equals(titulo) && aux.getMateria().equals(materia)){
                    editado=true;
                    aux.setTitulo(nuevo_titulo);
                    JOptionPane.showMessageDialog(null, "EDICION EXITOSA", null, JOptionPane.PLAIN_MESSAGE); 
                
                }
                else{
                    aux = aux.getSiguiente();
                }
            }
        }
        else{
            JOptionPane.showMessageDialog(null, "TITULO NO REGISTRADO, NO SE PUEDE EDITAR", "Error", JOptionPane.PLAIN_MESSAGE); 
        }
    }

    public void borrar_tarea(String materia,String titulo){
        if (buscar_tarea(materia,titulo)) {
            if (materia.equals(principio.getMateria())&&titulo.equals(principio.getTitulo())) {
                principio = principio.getSiguiente();
            } else{
                Tareas aux = principio;
                while(!aux.getSiguiente().getMateria().equals(materia)&&!aux.getSiguiente().getTitulo().equals(titulo)){
                    aux = aux.getSiguiente();
                }
                Tareas siguiente = aux.getSiguiente().getSiguiente();
                aux.setSiguiente(siguiente);  
                
            }
            JOptionPane.showMessageDialog(null, "TAREA TERMINADA", null, JOptionPane.PLAIN_MESSAGE);  
            tamanio_tar--;
        }
        else{
            JOptionPane.showMessageDialog(null, "TAREA NO REGISTRADA ERROR", "Error", JOptionPane.PLAIN_MESSAGE); 
        }
    }
        
    public String getValor(int posicion) throws Exception{
        if(posicion>=0 && posicion<tamanio_mat){
            if (posicion == 0) {
                return inicio.getNombre();
                
            }else{
                Materia aux = inicio;
                for (int i = 0; i < posicion; i++) {
                    aux = aux.getSiguiente();
                }
                return aux.getNombre();
            }
        } else {
            throw new Exception("Posicion inexistente en la lista.");
        }
    }
    public String getValor_tareasTitulo(int posicion, String materia) throws Exception{
        Tareas aux = principio;
        for (int i = 0; i < posicion; i++) {
            aux = aux.getSiguiente();   
        }   
        if(materia.equals(aux.getMateria())){
            return aux.getTitulo(); 
        }
        else{
            return "invalido";
        }
    }
    
    public String getValor_tareasDescrip(int posicion, String materia) throws Exception{
        Tareas aux = principio;
        for (int i = 0; i < posicion; i++) {
            aux = aux.getSiguiente();   
        }   
        if(materia.equals(aux.getMateria())){
            return aux.getDescripcion(); 
        }
        else{
            return "invalido";
        }
    }         
    public String Texto() {
        Materia auxiliar = inicio;
        Tareas auxi=principio;
        String aux = "";
        String tmp = "";
        while (auxiliar != null) {
            tmp = "";
            tmp = auxiliar.getNombre();
            if (auxiliar.getSiguiente() != null) {
                aux = aux + tmp + "*";
            } else {
                aux = aux + tmp;
            }
            auxiliar = auxiliar.getSiguiente();
        }
        aux=aux+"/";
        while (auxi != null) {
            tmp = "";
            tmp = auxi.getMateria()+"."+auxi.getTitulo()+"."+auxi.getDescripcion();
            if (auxi.getSiguiente() != null) {
                aux = aux + tmp + "-";
            } else {
                aux = aux + tmp;
            }
            auxi = auxi.getSiguiente();
        }
        aux=aux+"/";
        return aux;
    }
    public void dividir_texto(String texto){
        String texto1= "", texto2= "";
        int pasada=0;
        StringTokenizer token = new StringTokenizer(texto, "/");
        while (token.hasMoreElements()) {
            StringTokenizer ne = new StringTokenizer(token.nextToken(), "/");
            int i = 0;
            while (ne.hasMoreElements()) {
                if (i == 0) {
                    if(pasada==0){
                        texto1 = ne.nextToken();
                        CargaLista(texto1); 
                    }
                    if(pasada==1){
                        texto2 = ne.nextToken();
                        CargaLista_Tareas(texto2);
                        pasada++;
                        return;
                    }
                    pasada++;
                    System.out.println(texto1);
                    i++;
                }    
            }
            
        }
        
        
    }
    public void CargaLista(String texto) {
        String nombre = "";
        StringTokenizer token = new StringTokenizer(texto, "*");
        while (token.hasMoreElements()) {
            StringTokenizer ne = new StringTokenizer(token.nextToken(), "*");
            int i = 0;
            while (ne.hasMoreElements()) {
                if (i == 0) {
                    nombre = ne.nextToken();
                    i++;
                } 
            }
            if(!"\n".equals(nombre)){
                empilar_mat(nombre);
               // System.out.println("acaaa");
            }
        }
    }
    public void CargaLista_Tareas(String texto) {
        String nombre = "",titulo= "", descripcion= "";
        StringTokenizer token = new StringTokenizer(texto, "-");
        while (token.hasMoreElements()) {
            StringTokenizer ne = new StringTokenizer(token.nextToken(), ".");
            int i = 0;
            while (ne.hasMoreElements()) {
                if (i == 0) {
                    nombre = ne.nextToken();
                    i++;
                } 
                if(i==1){
                    titulo= ne.nextToken();
                    i++;
                }
                if(i==2){
                    descripcion=ne.nextToken();
                    i++;
                }
            }
            if(!"\n".equals(descripcion)){
                empilar_tarea(titulo,descripcion,nombre);
            }
            
        }
    }
}
